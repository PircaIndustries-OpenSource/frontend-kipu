export class ConcreteEntity {
  #id: string;
  #projectId: string;
  #sensorId: string;
  #state: string;
  #location: string;
  #temperature: number;
  #humidity: number;
  #limit: number;
  #unit: string;

  constructor() {
    this.#id = '';
    this.#projectId = '';
    this.#sensorId = '';
    this.#state = '';
    this.#location = '';
    this.#temperature = 0;
    this.#humidity = 0;
    this.#limit = 0;
    this.#unit = '';
  }

  get id(): string {
    return this.#id;
  }

  set id(value: string) {
    this.#id = value;
  }

  get projectId(): string {
    return this.#projectId;
  }

  set projectId(value: string) {
    this.#projectId = value;
  }

  get sensorId(): string {
    return this.#sensorId;
  }

  set sensorId(value: string) {
    this.#sensorId = value;
  }

  get state(): string {
    return this.#state;
  }

  set state(value: string) {
    this.#state = value;
  }

  get location(): string {
    return this.#location;
  }

  set location(value: string) {
    this.#location = value;
  }

  get temperature(): number {
    return this.#temperature;
  }

  set temperature(value: number) {
    this.#temperature = value;
  }

  get humidity(): number {
    return this.#humidity;
  }

  set humidity(value: number) {
    this.#humidity = value;
  }

  get limit(): number {
    return this.#limit;
  }

  set limit(value: number) {
    this.#limit = value;
  }

  get unit(): string {
    return this.#unit;
  }

  set unit(value: string) {
    this.#unit = value;
  }
}
